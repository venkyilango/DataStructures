import UIKit

var str = "Hello, playground"

public struct Queue<T>{
    fileprivate var array = [T?]()
    fileprivate var head = 0
    
    public var isEmpty: Bool{
        return array.isEmpty
    }
    
    public var arrCount: Int{
        return array.count -  head // position of head is decremented
    }
    
    public mutating func enqueue(_ element:T){
        array.append(element)
    }
    
//    public mutating func dequeue() -> T{
//        if isEmpty {
//            return nil
//        }else{
//            return array.removeFirst()
//        }
//    }
    
    public mutating func dequeue() -> T? {
        guard head < array.count, let element = array[head] else { return nil }
        
        array[head] = nil
        head += 1
        
        let percentage =  Double(head)/Double(array.count)
        print(percentage)
        print(Double(array.count))
        if array.count > 2 && percentage > 0.25 {
            array.removeFirst(head)
            print(head)
            head = 0
        }
        return element
    }
    
    public var front: T?{
        return array[head]
    }
    
//    public var front:T?{
//        return array.first
//    }
}

var queue = Queue<String>()
queue.enqueue("A")
queue.enqueue("B")
queue.enqueue("C")
queue.enqueue("D")
queue.enqueue("E")

queue.dequeue()
queue.dequeue()
queue.dequeue()

queue.array

queue.front
