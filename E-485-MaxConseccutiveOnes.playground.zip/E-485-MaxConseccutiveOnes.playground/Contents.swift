import UIKit

var str = "Hello, playground"


class Solution {
    var maxCount = 0, localCount = 0
    func findMaxConsecutiveOnes(_ nums: [Int]) -> Int {
        
        for num in nums{
            if num == 1{
                localCount += 1
                maxCount = max(maxCount, localCount)
            }else{
                localCount = 0
            }
        }
        return maxCount
    }
    
}

var input: [Int] = [0,1,0,0,1,1,1]
var solution = Solution()
solution.findMaxConsecutiveOnes(input)
