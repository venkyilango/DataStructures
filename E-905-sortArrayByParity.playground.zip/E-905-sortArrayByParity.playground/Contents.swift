import UIKit

var str = "Hello, playground"

class Solution {
    func sortArrayByParity(_ A: [Int]) -> [Int] {
        return A.filter{ $0 % 2 == 0} + A.filter{ $0 % 2 != 0}
    }
}
    
var input: [Int] = [3,1,2,4]
var solution = Solution()
solution.sortArrayByParity(input)
