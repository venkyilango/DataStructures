import UIKit

var str = "Hello, playground"

var inputArray : Array<Int> = [7, 4, 2, 8 , 0, 1, 5, 2]

extension Array where Element: Comparable{

    func insertionSort() -> Array<Element>{
        
        guard self.count > 1 else {
            return self
        }
        
        var output: Array<Element> = self
        
        print(output)
        
        for index in 0..<output.count {
            let key = output[index]
            var secondaryIndex = index
            
            while secondaryIndex > -1 {
                if key < output[secondaryIndex] {
                    output.remove(at: secondaryIndex+1)
                    output.insert(key, at: secondaryIndex)
                }
                secondaryIndex -= 1
                print(secondaryIndex)
            }
        }
        return output
    }

}

let outputArray : Array<Int> = inputArray.insertionSort()
