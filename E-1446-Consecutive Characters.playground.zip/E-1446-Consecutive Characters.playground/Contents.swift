import UIKit

var str = "Hello, playground"

class Solution {
    func maxPower(_ s: String) -> Int {
        var maxCharCount:Int = 0, maxTotalCount:Int = 0, currentChar:Character = " "
        for char in s{
            if char != currentChar {
                maxCharCount = 1
                currentChar = char
            }else {
                maxCharCount += 1
            }
            
            maxTotalCount = max(maxCharCount, maxTotalCount)
        }
        return maxTotalCount
    }
}

var input: String = "hellllloWorlddddddd"
var solution = Solution()
solution.maxPower(input)

