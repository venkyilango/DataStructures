import UIKit

var str = "Hello, playground"

public struct Stack<T>{
    fileprivate var array = [T]()


    public var count: Int{
        return array.count
    }
    

    public var isEmpty:Bool{
        return array.isEmpty
    }
    
    public mutating func push(_ element: T){
        array.append(element) // insert new element
    }
    
    public mutating func pop() -> T?{
        array.popLast() // pops the last inserted element
    }
    
    public var top: T? {
      return array.last // returns the top element
    }
    
}

var arrayOfProducts = Stack(array: ["A", "B", "C", "D", "E"])

arrayOfProducts.push("E")
arrayOfProducts.pop()
arrayOfProducts.isEmpty
arrayOfProducts.top
