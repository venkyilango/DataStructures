import UIKit

var str = "Hello, playground"


class Solution {
    func sortColors(_ nums: inout [Int]) {
        var red = 0, blue = nums.count - 1, i = 0
        
        while i <= blue {
            if nums[i] == 0 {
                _swap(&nums, i, red)
                red += 1
                i += 1
                print(nums)
            } else if nums[i] == 1 {
                i += 1
                print(nums)
            } else {
                _swap(&nums, i, blue)
                blue -= 1
                print(nums)
            }
        }
    }
    
    fileprivate func _swap<T>(_ nums: inout [T], _ p: Int, _ q: Int) {
        (nums[p], nums[q]) = (nums[q], nums[p])
        print((nums[p], nums[q]))
        print((nums[q], nums[p]))
    }
}

var input: [Int] = [2, 1, 0, 2, 1]
var solution = Solution()
solution.sortColors(&input)
